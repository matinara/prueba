
package main;

import model.Conexion;



public class Principal {

                
    
    public static void main(String[] args) {
         Conexion cn = new Conexion();
                 cn.conectar();

        
    }
    
}
